
document.addEventListener("DOMContentLoaded", () => {
  const publicSpreadsheetUrl = 'https://docs.google.com/spreadsheets/d/YOUR_SHEET_ID_HERE/pubhtml';

  Tabletop.init({
    key: publicSpreadsheetUrl,
    callback: showData,
    simpleSheet: false
  });

  function showData(data) {
    displayOfficeBearers(data.office_bearers.elements);
    displayNotifications(data.notifications.elements);
    displayAchievements(data.achievements.elements);
    displayGallery(data.gallery.elements);
    displayDocuments(data.documents.elements);
    displayContacts(data.contacts.elements);
  }

  function displayOfficeBearers(bearers) {
    const section = document.getElementById('office-bearers');
    bearers.forEach(person => {
      const div = document.createElement('div');
      div.innerHTML = `
        <h3>${person.Name} - ${person.Designation}</h3>
        <img src="${person.PhotoURL}" alt="${person.Name}" width="150"/>
        <p>Year: ${person.Year}</p>
      `;
      section.appendChild(div);
    });
  }

  function displayNotifications(notices) {
    const section = document.getElementById('notifications');
    const ul = document.createElement('ul');
    notices.forEach(note => {
      const li = document.createElement('li');
      li.textContent = `${note.Date} - ${note.Title}`;
      ul.appendChild(li);
    });
    section.appendChild(ul);
  }

  function displayAchievements(achievements) {
    const section = document.getElementById('achievements');
    achievements.forEach(entry => {
      const p = document.createElement('p');
      p.textContent = `${entry.Name} - ${entry.Achievement} (${entry.Year})`;
      section.appendChild(p);
    });
  }

  function displayGallery(photos) {
    const section = document.getElementById('gallery');
    photos.forEach(photo => {
      const div = document.createElement('div');
      div.innerHTML = `
        <img src="${photo.PhotoURL}" alt="${photo.Name}" width="200"/>
        <p>${photo.Name} - ${photo.Event} (${photo.Date})</p>
      `;
      section.appendChild(div);
    });
  }

  function displayDocuments(docs) {
    const section = document.getElementById('documents');
    docs.forEach(doc => {
      const p = document.createElement('p');
      p.innerHTML = `<strong>${doc.Year}</strong>: <a href="${doc.FileURL}" target="_blank">${doc.Title}</a>`;
      section.appendChild(p);
    });
  }

  function displayContacts(contacts) {
    const section = document.getElementById('contact');
    contacts.forEach(contact => {
      const p = document.createElement('p');
      p.innerHTML = `${contact.Type}: <a href="${getLink(contact.Type, contact.Value)}">${contact.Value}</a>`;
      section.appendChild(p);
    });
  }

  function getLink(type, value) {
    if (type.toLowerCase().includes("instagram")) {
      return `https://instagram.com/${value.replace("@", "")}`;
    } else if (type.toLowerCase().includes("whatsapp")) {
      return `https://wa.me/${value.replace(/\D/g, "")}`;
    } else if (type.toLowerCase().includes("email")) {
      return `mailto:${value}`;
    }
    return "#";
  }
});

document.getElementById("search-input").addEventListener("keyup", function () {
  const query = this.value.toLowerCase();
  const allText = document.body.innerText.toLowerCase();
  const results = allText.includes(query)
    ? `Found "${query}" on this page.`
    : `No results for "${query}".`;

  document.getElementById("search-results").textContent = results;
});
